<nav class="navbar fixed-bottom">
  <div class="d-flex justify-content-center pilih-footer align-items-end">
    <img src="assets/images/pooter.png" alt="nothing" class="footer-image">
    <p class="footer-text">&copy; COPYRIGHT TVRI</p>
  </div>
</nav>