<nav class="navbar fixed-top">
  <div class="container-fluid d-flex justify-content-between pilih-header">
    <a class="navbar-brand"><img loading="lazy"
        src="https://cdn.builder.io/api/v1/image/assets/TEMP/4feb6ccad9a610f4204c45122c24208d9de04359a6c03ff6713b688c8ca67784?placeholderIfAbsent=true&apiKey=c4e4ce5170a7404fac6bdd6b94daba06"
        class="pilih-logo" alt="PILIH logo" /></a>