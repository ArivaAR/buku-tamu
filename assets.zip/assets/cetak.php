<?php
// Koneksi ke database
include 'koneksi.php';

// Ambil ID pengunjung dari parameter GET
$id_pengunjung = $_GET['id'];

// Ambil parameter 'ubah' dari URL
$file = $_GET['ubah']; // Ini akan berisi 'pengunjung' atau nilai lainnya

// Query untuk mengambil data berdasarkan ID pengunjung
$query = mysqli_query($conn, "SELECT * FROM pengunjung WHERE id_pengunjung = '$id_pengunjung'");
$data = mysqli_fetch_array($query);

// Jika data tidak ditemukan
if (!$data) {
    echo "Data tidak ditemukan!";
    exit;
}

// Ambil data dari query
$nama = $data['nama'];
$no_id = $data['id_pengunjung'];
$foto_blob = $data['foto']; // Data foto dalam bentuk BLOB
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Kartu Pengunjung</title>
    <style>
        /* Styling untuk halaman secara umum */
        .box {
            width: 590px;
            height: 997px;
            font-family: sans-serif;
            background-image: url(images/Background.png); /* Gambar latar belakang */
            background-size: cover;
            background-position: center;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
        }

        .gambar-profil {
            height: 20rem;
            width: 20rem;
            border: 9px solid #ffffff;
            border-radius: 50%;
            margin-top: 35%;
            margin-bottom: 20px;
            background-size: cover;
            background-position: center;
        }

        h1, h2 {
            margin: 0;
            text-align: center;
        }

        h1 {
            font-size: 30px;
        }

        .nama, .jenis {
            margin-top: 30px;
        }

        .no-id {
            margin-top: auto;
        }

    </style>
    <script>
        // Memicu print otomatis ketika halaman dibuka
        window.onload = function() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="box">
        <!-- Menampilkan foto jika ada, jika tidak tampilkan gambar default -->
        <div class="gambar-profil" style="background-image: url('<?php 
            if ($foto_blob) {
                // Jika ada foto, konversi BLOB menjadi base64
                echo 'data:image/jpeg;base64,' . base64_encode($foto_blob);
            } else {
                // Jika tidak ada foto, tampilkan gambar default
                echo 'images/default-profile.png'; 
            }
        ?>');"></div>

        <!-- Menampilkan nama pengguna -->
        <h1 class="nama"><b><?php echo htmlspecialchars($nama); ?></b></h1>
        
        <!-- Menampilkan jenis pengunjung -->
        <h2 class="jenis">
            <?php
            // Menampilkan teks 'Pengunjung' jika parameter 'ubah' bernilai 'pengunjung'
            if ($file === 'pengunjung') {
                echo "Pengunjung";
            } else {
                echo "Jenis Tidak Dikenal";
            }
            ?>
        </h2>

        <!-- Menampilkan ID dengan huruf pertama ID 0 dan no_id -->
        <h2 class="no-id">ID 0<?php echo $no_id; ?></h2>
    </div>
</body>
</html>
