<?php
session_start(); // Mulai session untuk menyimpan status login

// Sertakan file koneksi database
include('assets/koneksi.php'); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Password yang dimasukkan

    // Query untuk mengambil data user berdasarkan username
    $query = "SELECT * FROM admin WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        // Ambil data user
        $user = mysqli_fetch_assoc($result);

        // Verifikasi password
        if ($password == $user['password']) {
            // Jika password cocok, login berhasil
            $_SESSION['username'] = $user['username']; // Simpan username ke session
            header("Location: dashboard.php"); // Redirect ke halaman dashboard
            exit();
        } else {
            // Jika password salah
            echo "<script>alert('Password salah!'); window.location.href = 'index.php';</script>";
        }
    } else {
        // Jika username tidak ditemukan
        echo "<script>alert('Username tidak ditemukan!'); window.location.href = 'index.php';</script>";
    }
}
?>